package bookpkg;
import java.util.Scanner;
import java.io.*;
import java.sql.*;
//import oracle.jdbc.driver.OracleDriver;
public class Book_App 
{
Scanner sc=new Scanner(System.in);
public static void main(String args[]) throws Exception
{
Scanner sc=new Scanner(System.in);
Book_App b=new Book_App();
int ch;
do{
System.out.println("enter your choice");
System.out.println("1. Insert");
System.out.println("2. Read or Fetch");

System.out.println("3. Update");
System.out.println("4. Delete");
System.out.println("5. Exit");
ch=sc.nextInt();
switch(ch)
{
case 1:  b.insert();
          break;
case 2: b.display();
         break;
case 3:   b.update();
         break;
case 4: b.delete();
        break;
case 5:  System.out.println("Thankyou!!");
default: 
    break;
}
}while(ch!=5);
}

public Connection getConnect()
{
try{
DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");

return con;
}catch(Exception e)
{
e.printStackTrace();
}
return null;
}

public void insert()
{
Book bo=new Book();
System.out.println("Enter the ISBN number");
bo.setISBN(sc.nextInt());

System.out.println("Enter the Book name");
bo.setBook_Name(sc.next());

System.out.println("Enter the Author name");
bo.setAuthor_Name(sc.next());

System.out.println("Enter the Edition");
bo.setEdition(sc.nextInt());


try{
Connection con=getConnect();
PreparedStatement ps=con.prepareStatement("insert into Book(ISBN,Book_Name,Author_Name,Edition) values(?,?,?,?)");
ps.setInt(1,bo.getISBN());
ps.setString(2,bo.getBook_Name());
ps.setString(3,bo.getAuthor_Name()); 
ps.setInt(4,bo.getEdition());

int x=ps.executeUpdate();
ps.close();
con.close();
if(x==1)
{
System.out.println("Inserted successfully");
}
}
catch(Exception e)
{
e.printStackTrace();
}
}

public void display()
{
try{
Connection con=getConnect();
PreparedStatement ps=con.prepareStatement("select * from book");
ResultSet rs=ps.executeQuery();
while(rs.next()){
System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
}
rs.close();
ps.close();
con.close();
}
catch(Exception e)
{
e.printStackTrace();
}
}


public void delete()
{
try{
int i;
System.out.println("Enter the ISBN number to delete");
i=sc.nextInt();
Connection con=getConnect();
PreparedStatement ps=con.prepareStatement("delete from Book where ISBN=? ");
ps.setInt(1,i);

int x=ps.executeUpdate();
ps.close();
con.close();
if(x==1)
{
System.out.println("Deleted successfully");
}
else{
System.out.println("Record Not found");
}
}
catch(Exception e)
{
e.printStackTrace();
}
}


public void update()
{
Book bo=new Book();
System.out.println("Enter the ISBN number");
int i=sc.nextInt();
bo.setISBN(i);
System.out.println("What is the Edition Number you want to update?");
int edi=sc.nextInt();
bo.setEdition(edi);

try
{
Connection con=getConnect();
String str="update Book set Edition=? where ISBN=?";
PreparedStatement ps=con.prepareStatement(str);
ps.setInt(1,bo.getEdition());
ps.setInt(2,bo.getISBN());
int x=ps.executeUpdate();

ps.close();
con.close();
if(x==1)
{
System.out.println("Updated successfully");
}
else{
System.out.println("Record Not found");
}
}
catch(Exception e)
{
e.printStackTrace();
}
}}